Contributors
============

* Aarni Koskela <akx@iki.fi>
* Aitzol Naberan <anaberan@codesyntax.com>
* Aljosa Mohorovic <aljosa.mohorovic@gmail.com>
* Andy Venet <avenet@users.noreply.github.com>
* BakaNeko <meganekko@list.ru>
* Chem <Chemt@ukr.net>
* Claude Paroz <claude@2xlibre.net>
* Craig de Stigter <craig.destigter@koordinates.com>
* Dan Moore <dan@moore.cx>
* David Harks <dave@dwink.net>
* Fred Stluka <fred@bristle.com>
* Guilherme Rezende <guilhermebr@gmail.com>
* Hugo Des <hugo.deslongchamps@smile.fr>
* Ian Bruce <ian@projectbruce.net>
* Jaap Roes <jaap@eight.nl>
* James Cleveland <jamescleveland@gmail.com>
* Jason Davies <jason@jasondavies.com>
* Jessamyn Smith <jessamyn.smith@gmail.com>
* Joel Burton <joel@joelburton.com>
* Jonathan D. Baker <jonathandavidbaker@gmail.com>
* Joost Cassee <joost@cassee.net>
* Lee Semel <lee@semel.net>
* Matt Archibald <marchiba@u.rochester.edu>
* Peter van Kampen <pterk@datatailors.com>
* Piet Delport <piet@byteorbit.com>
* Pokutnik Alexandr <pokutnik@gmail.com>
* Quadracik <quadracik@gmail.com>
* Rémy HUBSCHER <rhubscher@mozilla.com>
* Steffen Jasper <jesus_at_hollywoodparty@gmx.net>
* Tim Saylor <tim.saylor@gmail.com>
* Venelin Stoykov <vkstoykov@gmail.com>
* Zuzel Vera <zuzel.vp@gmail.com>
* Ivan Chernov <chernoffivan@gmail.com>
* Andrew Meakovski <meako689@gmail.com>
* Tom Chiung-ting Chen <ctchen@gmail.com>
* Dima Revutskyi <rddimon@gmail.com>
